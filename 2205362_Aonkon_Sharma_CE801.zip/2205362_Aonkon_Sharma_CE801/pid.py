import rclpy

import math
import csv
 

from rclpy.node import Node

from sensor_msgs.msg import LaserScan

from geometry_msgs.msg import Twist

from nav_msgs.msg import Odometry

from tf2_ros import TransformRegistration

from rclpy.qos import QoSProfile, QoSReliabilityPolicy

 

mynode_ = None

pub_ = None

regions_ = {

    'right': 0,

    'fright': 0,

    'front': 0,

    'fleft': 0,

    'left': 0,

}

twstmsg_ = None

 

# main function attached to timer callback

def timer_callback():

    global pub_, twstmsg_

    if ( twstmsg_ != None ):

        pub_.publish(twstmsg_)

 

 

def clbk_laser(msg):

    global regions_, twstmsg_

   

    regions_ = {

        #LIDAR readings are anti-clockwise

        #'right':  find_nearest(msg.ranges[265:275]),
        'right':  find_nearest(msg.ranges[95:105]),
        #'right':  find_nearest(msg.ranges[130:160]),

        #'fright': find_nearest (msg.ranges[310:320]),
        'fright': find_nearest (msg.ranges[130:140]),
        #'fright': find_nearest (msg.ranges[150:190]),

        #'front':  find_nearest (msg.ranges[5:355]),
        'front':  find_nearest (msg.ranges[175:185]),
        #'front':  find_nearest (msg.ranges[90:150]),
	
	#'bright':  find_nearest (msg.ranges[30:40]),
	#back side of front
        #'fleft':  find_nearest (msg.ranges[40:50]),
        'fleft':  find_nearest (msg.ranges[220:230]),
        #'fleft':  find_nearest (msg.ranges[240:300]),
	#'bleft':  find_nearest (msg.ranges[330:340]),
        #'left':   find_nearest (msg.ranges[85:95]),
        'left':   find_nearest (msg.ranges[265:275]),
        #'left':   find_nearest (msg.ranges[285:305]),

       

    }   

    twstmsg_= movement()

 

   

# Find nearest point

def find_nearest(list):

    f_list = filter(lambda item: item > 0.0, list)  # exclude zeros

    return min(min(f_list, default=10), 10)

 

#Basic movement method

def movement():

    global regions_, mynode_

    regions = regions_

    print("Min distance in front region: ", regions['front'])

   

    #create an object of twist class, used to express the linear and angular velocity of the turtlebot

    msg = Twist()

    #Variables

    KP=0.7#0.8 #0.7 #0.8#0.5#0.4

    KI=0.03 #0.05 #0.01#0.04#0.03#0.02

    KD=0.01 #0.0#0.02 #0.01

   

    desired_distance =0.5 #0.25

    Err = desired_distance -regions['right']

    ErrI=+Err

    Errp= Err

    ErrD=Err- Errp
    Errp = Err
    Output = (KP * Err)+(KI * ErrI)+(KD * ErrD)
    
    with open('PID DATA COLLACTION.csv', 'a', newline='') as csvfile:
      fieldnames = ['KP', 'KI', 'KD','desired_distance', 'Fleft', 'Fright','left','right','Err','ErrI','ErrD','Errp', 'Output']
      writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

      writer.writeheader()
      writer.writerow({'KP': KP, 'KI': KI, 'KD' : KD,'desired_distance':desired_distance, 'Fleft': regions['fleft'], 'Fright':regions['fright'], 'left':regions['left'], 'right':regions['right'],'Err':Err,'ErrI':ErrI,'ErrD':ErrD,'Errp':Errp, 'Output': Output})
    ###//
    
    #print(Output, regions['front'], "Right: ", regions['right'],  "Left: ", regions['left'])
    #print(Output, regions['fleft'], Err)

    msg.linear.x = -0.1
    msg.angular.z = Output
    return msg
  

def stop():

    global pub_

    msg = Twist()

    msg.angular.z = 0.0

    msg.linear.x = 0.0

    pub_.publish(msg)

 

 

def main():

    global pub_, mynode_

 

    rclpy.init()

    mynode_ = rclpy.create_node('reading_laser')

 

    # define qos profile (the subscriber default 'reliability' is not compatible with robot publisher 'best effort')

    qos = QoSProfile(

        depth=10,

        reliability=QoSReliabilityPolicy.RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT,

    )

 

    # publisher for twist velocity messages (default qos depth 10)

    pub_ = mynode_.create_publisher(Twist, '/cmd_vel', 10)

 

    # subscribe to laser topic (with our qos)

    sub = mynode_.create_subscription(LaserScan, '/scan', clbk_laser, qos)

 

    # Configure timer

    timer_period = 0.2  # seconds

    timer = mynode_.create_timer(timer_period, timer_callback)

 

    # Run and handle keyboard interrupt (ctrl-c)

    try:

        rclpy.spin(mynode_)

    except KeyboardInterrupt:

        stop()  # stop the robot

    except:

        stop()  # stop the robot

    finally:

        # Clean up

        mynode_.destroy_timer(timer)

        mynode_.destroy_node()

        rclpy.shutdown()

 

if __name__ == '__main__':

    main()
