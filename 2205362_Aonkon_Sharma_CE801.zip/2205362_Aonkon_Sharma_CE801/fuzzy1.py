from termios import VEOL
import rclpy
import math

from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf2_ros import TransformRegistration
from rclpy.qos import QoSProfile, QoSReliabilityPolicy


mynode_ = None
pub_ = None
regions_ = {
    'right': 0,
    'fright': 0,
    'front': 0,
    'fleft': 0,
    'left': 0,
}
twstmsg_ = None

# main function attached to timer callback
def timer_callback():
    global pub_, twstmsg_
    if ( twstmsg_ != None ):
        pub_.publish(twstmsg_)


def clbk_laser(msg):
    global regions_, twstmsg_
   
    regions_ = {
        #LIDAR readings are anti-clockwise
        'fleft':  find_nearest (msg.ranges[130:150]),
        #'fleft':  find_nearest (msg.ranges[275:305]),
        'bleft':   find_nearest (msg.ranges[150:190]),
        #'bleft':  find_nearest (msg.ranges[20:40]),
        'front':  find_nearest (msg.ranges[90:150]),
        #'front':  find_nearest (msg.ranges[155:185]),
        'bright':  find_nearest(msg.ranges[240:300]),
        #'bright':  find_nearest (msg.ranges[300:340]),
        'fright': find_nearest (msg.ranges[285:305]),
        #'fright': find_nearest (msg.ranges[240:300]),

    }    
    twstmsg_= movement()

# Find nearest point
def find_nearest(list):
    f_list = filter(lambda item: item > 0.0, list)  # exclude zeros
    return min(min(f_list, default=10), 10)
   
# Find nearest point
def falling_edge (x,fuzzy_set):
    c=fuzzy_set[1];b=fuzzy_set[2]
    y= (c-x)/(c-b)
    return y

def rising_edge (x,fuzzy_set):
    a=fuzzy_set[0];b=fuzzy_set[1]
    y= (x-a)/(b-a)
    return y

def mem_function (sensor_input):
    x=sensor_input;memb_value_near=0;Memb_value_med=0;Memb_value_far=0
   
    # fuzzy sets declaration
    near= [0.0,0.2,0.4]
    medium=[0.2,0.4,0.6]
    far=[0.4,0.6,0.8]

   
    # Membership value calculation
    if x> 0.2 and x < 0.4:
        memb_value_near = falling_edge (x,near)
        Memb_value_med= rising_edge (x,medium)
   
    if x<= 0.2:
        memb_value_near = 1.0

    if  x> 0.4 and x < 0.6:
        Memb_value_med = falling_edge (x,medium)
        Memb_value_far = rising_edge (x,far)

    if x>= 0.6:
        Memb_value_far = 1.0
   
    return (memb_value_near,Memb_value_med,Memb_value_far)

def fuzzy_rules (rfs_near,rfs_med,rfs_far,rbs_near,rbs_med,rbs_far):
    #fire_strn_slow=0.0;fire_strn_medium=0.0;fire_strn_fast=0.0

    speed_slow = [0.0,0.03,0.06] #[0.0, 0.02, 0.04],[0.0, 0.01, -0.04]
    speed_medium = [0.07,0.09,0.12] #[0.04, 0.25, 0.03],
    speed_fast = [0.13,0.15,0.18]#[0.06, 0.07, 0.2]

    direction_left = [1.5,1.0,0.5]#[-0.10, -0.08, -0.04],
    direction_straight = [0.6,0.0,-0.5]#[0, 0, 0],
    direction_right = [-0.6,-0.1,-1.5]#[0.04, 0.03, 0.12]
  
    r1 = min (rfs_near, rbs_near)
    r2 = min (rfs_near, rbs_med)
    r3 = min (rfs_near,rbs_far)
    r4 = min (rfs_med,rbs_near)
    r5 = min (rfs_med,rbs_med)
    r6 = min (rfs_med,rbs_far)
    r7 = min (rfs_far,rbs_near)
    r8 = min (rfs_far,rbs_med)
    r9 = min (rfs_far,rbs_far)

    fire_strn_slow = (r1+r2+r4)
    fire_strn_medium= (r3+r6+r7)
    fire_strn_fast= (r5+r8+r9)
   
    fire_strn_left = (r1+r2+r3+r6)
    fire_strn_straight= (r5)
    fire_strn_right= (r4+r7+r8+r9)
   
    print('fire_strn_slow - ',fire_strn_slow)
    print('fire_strn_medium - ',fire_strn_medium)
    print('fire_strn_fast - ',fire_strn_fast)

    print('fire_strn_left - ',fire_strn_left)
    print('fire_strn_straight - ',fire_strn_straight)
    print('fire_strn_right - ',fire_strn_right)

    if ((speed_slow[1]+speed_medium[1]+speed_fast[1]) != 0):
        numerator = (fire_strn_slow*speed_slow[1])+(fire_strn_medium*speed_medium[1])+(fire_strn_fast*speed_fast[1])
        denom=(fire_strn_slow+fire_strn_medium+fire_strn_fast)
        #print('numerator',numerator)
        #print('denom',denom)
        velocity = numerator/denom
       
    else:

        velocity =0.0

    if ((direction_left[1]+direction_straight[1]+direction_right[1])!= 0):
        numerator = ((fire_strn_left*direction_left[1])+(fire_strn_straight*direction_straight[1])+(fire_strn_right*direction_right[1]))
        denom=(fire_strn_left+fire_strn_straight+fire_strn_right)
       
        angular_velocity=numerator/denom

    else:

        angular_velocity= 0.0
       
    return (velocity, angular_velocity)



#Basic movement method
def movement():
    global regions_, mynode_
    regions = regions_
    velocity= 0.0
    angular_velocity=0.0
    print('Hi')
    right_front_sensor_value = regions['fleft']
    right_back_sensor_value = regions['bleft']
   
    #create an object of twist class, used to express the linear and angular velocity of the turtlebot
    msg = Twist()

    # membershif values for each sensor
    rfs_near,rfs_med,rfs_far = mem_function(right_front_sensor_value)
    rbs_near,rbs_med,rbs_far = mem_function(right_back_sensor_value)

    # firing strength calculated and # center of sets defuzzification is calculated and returned.
    velocity,angular_velocity = fuzzy_rules (rfs_near,rfs_med,rfs_far,rbs_near,rbs_med,rbs_far)
    print(angular_velocity)
    msg.linear.x = -velocity
    msg.angular.z= angular_velocity
    return msg

#used to stop the rosbot
def stop():
    global pub_
    msg = Twist()
    msg.angular.z = 0.0
    msg.linear.x = 0.0
    pub_.publish(msg)


def main():
    global pub_, mynode_

    rclpy.init()
    mynode_ = rclpy.create_node('reading_laser')

    # define qos profile (the subscriber default 'reliability' is not compatible with robot publisher 'best effort')
    qos = QoSProfile(
        depth=10,
        reliability=QoSReliabilityPolicy.RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT,
    )

    # publisher for twist velocity messages (default qos depth 10)
    pub_ = mynode_.create_publisher(Twist, '/cmd_vel', 10)

    # subscribe to laser topic (with our qos)
    sub = mynode_.create_subscription(LaserScan, '/scan', clbk_laser, qos)

    # Configure timer
    timer_period = 0.2  # seconds
    timer = mynode_.create_timer(timer_period, timer_callback)

    # Run and handle keyboard interrupt (ctrl-c)
    try:
        rclpy.spin(mynode_)
    except KeyboardInterrupt:
        stop()  # stop the robot
    except:
        stop()  # stop the robot
    finally:
        # Clean up
        mynode_.destroy_timer(timer)
        mynode_.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
